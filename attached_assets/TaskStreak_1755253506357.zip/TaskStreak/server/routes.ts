import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all tasks
  app.get("/api/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });

  // Get daily progress for a specific date
  app.get("/api/progress/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const progress = await storage.getDailyProgress(date);
      
      if (!progress) {
        // Return default progress for new dates
        res.json({
          date,
          completedTasks: [],
          streakCount: 0,
          totalTasks: 8,
        });
      } else {
        res.json(progress);
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch progress" });
    }
  });

  // Update daily progress
  app.post("/api/progress/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const updateSchema = z.object({
        completedTasks: z.array(z.string()),
        completedSubTasks: z.array(z.string()).optional(),
      });
      
      const { completedTasks, completedSubTasks } = updateSchema.parse(req.body);
      const progress = await storage.updateDailyProgress(date, completedTasks, completedSubTasks || []);
      
      res.json(progress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid request data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update progress" });
      }
    }
  });

  // Get streak count for a specific date
  app.get("/api/streak/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const streakCount = await storage.getStreakCount(date);
      res.json({ streakCount });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch streak" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
