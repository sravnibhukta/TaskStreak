import { type Task, type InsertTask, type DailyProgress, type InsertDailyProgress, type SubTask } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getTasks(): Promise<Task[]>;
  getDailyProgress(date: string): Promise<DailyProgress | undefined>;
  createDailyProgress(progress: InsertDailyProgress): Promise<DailyProgress>;
  updateDailyProgress(date: string, completedTasks: string[], completedSubTasks?: string[]): Promise<DailyProgress>;
  getStreakCount(date: string): Promise<number>;
}

export class MemStorage implements IStorage {
  private tasks: Map<string, Task>;
  private dailyProgress: Map<string, DailyProgress>;

  constructor() {
    this.tasks = new Map();
    this.dailyProgress = new Map();
    this.initializeTasks();
  }

  private initializeTasks() {
    const defaultTasks: Omit<Task, 'id'>[] = [
      {
        name: "Early Morning Study",
        emoji: "📚",
        timeSlot: "4:00 - 5:10AM",
        description: "GATE Paper Practice",
        duration: 70,
        borderColor: "border-purple-500",
        badgeColor: "text-purple-600 bg-purple-100",
        order: 1,
        isMainTask: true,
        subTasks: [
          { id: "prev-gate", name: "Previous GATE Paper Solving", emoji: "📝" }
        ],
      },
      {
        name: "Morning Yoga",
        emoji: "🧘‍♀️",
        timeSlot: "5:20 - 6:30AM",
        description: "Mind & Body Balance",
        duration: 70,
        borderColor: "border-green-500",
        badgeColor: "text-green-600 bg-green-100",
        order: 2,
        isMainTask: true,
        subTasks: [],
      },
      {
        name: "Morning Study",
        emoji: "💻",
        timeSlot: "7:00 - 11:00AM",
        description: "Core CS Subjects",
        duration: 240,
        borderColor: "border-blue-500",
        badgeColor: "text-blue-600 bg-blue-100",
        order: 3,
        isMainTask: true,
        subTasks: [
          { id: "algo", name: "ALGO", emoji: "🧠" },
          { id: "ds", name: "DS", emoji: "🗂️" },
          { id: "pl", name: "PL", emoji: "💻" },
          { id: "cd", name: "CD", emoji: "⚙️" }
        ],
      },
      {
        name: "Morning Study",
        emoji: "📐",
        timeSlot: "11:30AM - 1:30PM",
        description: "Mathematics",
        duration: 120,
        borderColor: "border-indigo-500",
        badgeColor: "text-indigo-600 bg-indigo-100",
        order: 4,
        isMainTask: true,
        subTasks: [
          { id: "dmath", name: "DMATH", emoji: "📊" },
          { id: "emath", name: "EMATH", emoji: "⚡" },
          { id: "napt", name: "N/APT", emoji: "🔢" }
        ],
      },
      {
        name: "Afternoon Study",
        emoji: "🔬",
        timeSlot: "2:30 - 5:00PM",
        description: "Theory & Logic",
        duration: 150,
        borderColor: "border-orange-500",
        badgeColor: "text-orange-600 bg-orange-100",
        order: 5,
        isMainTask: true,
        subTasks: [
          { id: "toc", name: "TOC", emoji: "🔄" },
          { id: "digital", name: "DIGITAL", emoji: "🔌" }
        ],
      },
      {
        name: "Evening Exercise",
        emoji: "🏃‍♂️",
        timeSlot: "5:00 - 5:30PM",
        description: "Physical Fitness",
        duration: 30,
        borderColor: "border-red-500",
        badgeColor: "text-red-600 bg-red-100",
        order: 6,
        isMainTask: true,
        subTasks: [],
      },
      {
        name: "Evening Study",
        emoji: "🌅",
        timeSlot: "5:30 - 8:30PM",
        description: "Systems & Networks",
        duration: 180,
        borderColor: "border-teal-500",
        badgeColor: "text-teal-600 bg-teal-100",
        order: 7,
        isMainTask: true,
        subTasks: [
          { id: "os", name: "OS", emoji: "🖥️" },
          { id: "dbms", name: "DBMS", emoji: "🗄️" },
          { id: "cnw-co", name: "CNW/CO", emoji: "🌐" }
        ],
      },
      {
        name: "Sleep",
        emoji: "😴",
        timeSlot: "9:00PM - 4:00AM",
        description: "7 Hours Rest",
        duration: 420,
        borderColor: "border-purple-600",
        badgeColor: "text-purple-600 bg-purple-100",
        order: 8,
        isMainTask: true,
        subTasks: [],
      },
    ];

    defaultTasks.forEach(task => {
      const id = randomUUID();
      this.tasks.set(id, { ...task, id });
    });
  }

  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values()).sort((a, b) => a.order - b.order);
  }

  async getDailyProgress(date: string): Promise<DailyProgress | undefined> {
    return this.dailyProgress.get(date);
  }

  async createDailyProgress(progress: InsertDailyProgress): Promise<DailyProgress> {
    const id = randomUUID();
    const newProgress: DailyProgress = { 
      id,
      date: progress.date,
      completedTasks: progress.completedTasks || [],
      completedSubTasks: progress.completedSubTasks || [],
      streakCount: progress.streakCount || 0,
      totalTasks: progress.totalTasks || 8,
      totalSubTasks: progress.totalSubTasks || 15
    };
    this.dailyProgress.set(progress.date, newProgress);
    return newProgress;
  }

  async updateDailyProgress(date: string, completedTasks: string[], completedSubTasks: string[] = []): Promise<DailyProgress> {
    let progress = this.dailyProgress.get(date);
    
    if (!progress) {
      // Create new progress for the date
      progress = await this.createDailyProgress({
        date,
        completedTasks: completedTasks || [],
        completedSubTasks: completedSubTasks || [],
        streakCount: await this.calculateStreakCount(date, completedTasks || [], completedSubTasks || []),
        totalTasks: 8,
        totalSubTasks: 15,
      });
    } else {
      // Update existing progress
      progress.completedTasks = Array.isArray(completedTasks) ? completedTasks : [];
      progress.completedSubTasks = Array.isArray(completedSubTasks) ? completedSubTasks : [];
      progress.streakCount = await this.calculateStreakCount(date, completedTasks || [], completedSubTasks || []);
      this.dailyProgress.set(date, progress);
    }
    
    return progress;
  }

  async getStreakCount(date: string): Promise<number> {
    const progress = this.dailyProgress.get(date);
    return progress?.streakCount || 0;
  }

  private async calculateStreakCount(currentDate: string, completedTasks: string[], completedSubTasks: string[] = []): Promise<number> {
    // If current day is not complete, return 0
    if (completedTasks.length < 8 || completedSubTasks.length < 10) {
      return 0;
    }

    let streak = 1; // Current day counts as 1
    const current = new Date(currentDate);
    
    // Go backwards day by day to count consecutive completed days
    for (let i = 1; i < 32; i++) { // Max 32 days for the challenge
      const checkDate = new Date(current);
      checkDate.setDate(current.getDate() - i);
      const dateStr = checkDate.toISOString().split('T')[0];
      
      const progress = this.dailyProgress.get(dateStr);
      if (progress && progress.completedTasks.length === 8 && (progress.completedSubTasks?.length || 0) >= 10) {
        streak++;
      } else {
        break;
      }
    }
    
    return streak;
  }
}

export const storage = new MemStorage();
