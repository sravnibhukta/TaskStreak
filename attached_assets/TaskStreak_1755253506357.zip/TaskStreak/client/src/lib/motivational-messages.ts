export interface MotivationalMessage {
  emoji: string;
  title: string;
  message: string;
}

export const motivationalMessages: MotivationalMessage[] = [
  { 
    emoji: "🎉", 
    title: "Fantastic!", 
    message: "You're crushing your goals today! Keep the momentum going!" 
  },
  { 
    emoji: "⭐", 
    title: "Star Student!", 
    message: "Your dedication is inspiring! You're building greatness daily!" 
  },
  { 
    emoji: "🔥", 
    title: "On Fire!", 
    message: "Your consistency is your superpower! Keep burning bright!" 
  },
  { 
    emoji: "💪", 
    title: "Strength Mode!", 
    message: "Every completed task is building a stronger you!" 
  },
  { 
    emoji: "🚀", 
    title: "Sky High!", 
    message: "You're launching towards success! Nothing can stop you now!" 
  },
  { 
    emoji: "💎", 
    title: "Diamond Level!", 
    message: "Pressure makes diamonds - you're becoming precious!" 
  },
  { 
    emoji: "🏆", 
    title: "Champion!", 
    message: "Winners like you are made of consistency and determination!" 
  },
  { 
    emoji: "⚡", 
    title: "Electric!", 
    message: "Your energy and focus are absolutely electrifying!" 
  },
  { 
    emoji: "🌟", 
    title: "Brilliant!", 
    message: "Your commitment to excellence shines bright!" 
  },
  { 
    emoji: "🎯", 
    title: "Bulls-eye!", 
    message: "Perfect aim towards your dreams! You're hitting every target!" 
  },
];

export function getRandomMotivationalMessage(): MotivationalMessage {
  return motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
}
