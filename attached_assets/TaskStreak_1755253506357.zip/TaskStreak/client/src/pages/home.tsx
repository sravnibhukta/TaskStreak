import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, RotateCcw, CheckCheck, Download, Calendar, Flame } from "lucide-react";
import { Task, DailyProgress } from "@shared/schema";
import { AdvancedTaskCard } from "@/components/advanced-task-card";
import { ProgressRing } from "@/components/progress-ring";
import { MotivationalPopup } from "@/components/motivational-popup";
import { getRandomMotivationalMessage, MotivationalMessage } from "@/lib/motivational-messages";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";

const CHALLENGE_START = new Date('2025-08-16');
const CHALLENGE_END = new Date('2025-09-16');

export default function Home() {
  const [currentDate, setCurrentDate] = useState(() => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    const startStr = CHALLENGE_START.toISOString().split('T')[0];
    const endStr = CHALLENGE_END.toISOString().split('T')[0];
    
    // If today is within challenge period, use today, otherwise use start date
    if (todayStr >= startStr && todayStr <= endStr) {
      return today;
    }
    return CHALLENGE_START;
  });

  const [showPopup, setShowPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState<MotivationalMessage>(getRandomMotivationalMessage());
  const [completedSubTasks, setCompletedSubTasks] = useState<string[]>([]);

  const currentDateStr = currentDate.toISOString().split('T')[0];
  const queryClient = useQueryClient();

  // Fetch tasks
  const { data: tasks = [], isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  // Fetch daily progress
  const { data: progress, isLoading: progressLoading } = useQuery<DailyProgress>({
    queryKey: ['/api/progress', currentDateStr],
  });

  // Update completed sub-tasks when progress loads
  useEffect(() => {
    if (progress?.completedSubTasks) {
      setCompletedSubTasks(progress.completedSubTasks);
    }
  }, [progress]);

  // Update progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: async ({ completedTasks, completedSubTasks }: { completedTasks: string[], completedSubTasks: string[] }) => {
      const response = await apiRequest('POST', `/api/progress/${currentDateStr}`, {
        completedTasks,
        completedSubTasks,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/progress'] });
    },
  });

  const completedTasks = progress?.completedTasks || [];
  const totalTasks = tasks.length;
  const totalSubTasks = tasks.reduce((acc, task) => acc + (task.subTasks?.length || 0), 0);
  const dailyProgress = totalTasks > 0 ? (completedTasks.length / totalTasks) * 100 : 0;
  const subTaskProgress = totalSubTasks > 0 ? (completedSubTasks.length / totalSubTasks) * 100 : 0;

  // Calculate challenge day
  const challengeDay = Math.floor((currentDate.getTime() - CHALLENGE_START.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  const totalChallengeDays = Math.floor((CHALLENGE_END.getTime() - CHALLENGE_START.getTime()) / (1000 * 60 * 60 * 24)) + 1;

  // Calculate overall progress (simplified - based on current day)
  const overallProgress = Math.min((challengeDay / totalChallengeDays) * 100, 100);

  const handleTaskToggle = (taskId: string) => {
    const newCompletedTasks = completedTasks.includes(taskId)
      ? completedTasks.filter(id => id !== taskId)
      : [...completedTasks, taskId];

    // Show popup only when completing a task (not unchecking)
    if (!completedTasks.includes(taskId)) {
      setPopupMessage(getRandomMotivationalMessage());
      setShowPopup(true);
    }

    updateProgressMutation.mutate({ completedTasks: newCompletedTasks, completedSubTasks });
  };

  const handleSubTaskToggle = (subTaskId: string) => {
    const newCompletedSubTasks = completedSubTasks.includes(subTaskId)
      ? completedSubTasks.filter(id => id !== subTaskId)
      : [...completedSubTasks, subTaskId];

    setCompletedSubTasks(newCompletedSubTasks);

    // Show popup only when completing a sub-task (not unchecking)
    if (!completedSubTasks.includes(subTaskId)) {
      setPopupMessage(getRandomMotivationalMessage());
      setShowPopup(true);
    }

    updateProgressMutation.mutate({ completedTasks, completedSubTasks: newCompletedSubTasks });
  };

  const handlePreviousDay = () => {
    const prevDay = new Date(currentDate);
    prevDay.setDate(currentDate.getDate() - 1);
    if (prevDay >= CHALLENGE_START) {
      setCurrentDate(prevDay);
    }
  };

  const handleNextDay = () => {
    const nextDay = new Date(currentDate);
    nextDay.setDate(currentDate.getDate() + 1);
    if (nextDay <= CHALLENGE_END) {
      setCurrentDate(nextDay);
    }
  };

  const handleResetDay = () => {
    setCompletedSubTasks([]);
    updateProgressMutation.mutate({ completedTasks: [], completedSubTasks: [] });
  };

  const handleCompleteAll = () => {
    const allTaskIds = tasks.map(task => task.id);
    const allSubTaskIds = tasks.flatMap(task => task.subTasks?.map(st => st.id) || []);
    setCompletedSubTasks(allSubTaskIds);
    updateProgressMutation.mutate({ completedTasks: allTaskIds, completedSubTasks: allSubTaskIds });
    setPopupMessage(getRandomMotivationalMessage());
    setShowPopup(true);
  };

  const handleExportData = () => {
    // Simple export functionality
    const data = {
      date: currentDateStr,
      completedTasks,
      completedSubTasks,
      progress: dailyProgress,
      subTaskProgress,
      streakCount: progress?.streakCount || 0,
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `challenge-progress-${currentDateStr}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (tasksLoading || progressLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl font-medium">Loading your challenge...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-4xl">
      {/* Header Section */}
      <header className="gradient-card rounded-2xl shadow-xl p-6 mb-6 border-l-4 border-primary neon-glow">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-center md:text-left">
            <h1 className="text-3xl md:text-4xl font-poppins font-bold text-gray-800 mb-2 rainbow-text">
              🎯 KANTUBHUKTA SRAVANI's GATE Challenge
            </h1>
            <p className="text-gray-600 font-medium mb-2">
              1 Month Study Challenge • Aug 16 - Sep 16, 2025
            </p>
            <div className="goal-card rounded-lg p-3 mt-2">
              <div className="flex flex-wrap gap-2 text-sm">
                <span>🎯 Target: 80+ Marks</span>
                <span>📝 Solve: 55/65 Questions</span>
                <span>🏆 Rank: Top 200</span>
                <span>💯 Total: 100 Marks</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            {/* Streak Counter */}
            <div className="text-center bg-gradient-to-r from-orange-400 via-pink-500 to-red-500 text-white px-6 py-3 rounded-xl shadow-lg neon-glow">
              <div className="text-2xl font-bold">{progress?.streakCount || 0}</div>
              <div className="text-sm font-medium flex items-center justify-center">
                <Flame className="w-4 h-4 mr-1 pulse-ring" />
                Day Streak
              </div>
            </div>
            
            {/* Overall Progress */}
            <div className="text-center">
              <ProgressRing progress={overallProgress} />
              <p className="text-sm text-gray-600 mt-1">Challenge Progress</p>
            </div>
          </div>
        </div>
      </header>

      {/* Date Navigation */}
      <div className="gradient-card rounded-xl shadow-lg p-4 mb-6">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={handlePreviousDay}
            disabled={currentDate <= CHALLENGE_START}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <div className="text-center">
            <h2 className="text-xl font-poppins font-semibold text-gray-800">
              📅 {currentDate.toLocaleDateString('en-US', { 
                weekday: 'long',
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </h2>
            <p className="text-sm text-gray-500">
              Day {challengeDay} of {totalChallengeDays}
            </p>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleNextDay}
            disabled={currentDate >= CHALLENGE_END}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Daily Progress Bar */}
        <div className="mt-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">Today's Progress</span>
            <span className="text-sm font-bold text-primary">
              {completedTasks.length}/{totalTasks} Tasks • {completedSubTasks.length}/{totalSubTasks} Subjects
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-primary to-challenge-secondary h-3 rounded-full transition-all duration-500"
              style={{ width: `${(dailyProgress + subTaskProgress) / 2}%` }}
            />
          </div>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-4 mb-6">
        {tasks.map((task) => (
          <AdvancedTaskCard
            key={task.id}
            task={task}
            isCompleted={completedTasks.includes(task.id)}
            completedSubTasks={completedSubTasks}
            onToggle={handleTaskToggle}
            onSubTaskToggle={handleSubTaskToggle}
          />
        ))}
      </div>

      {/* Statistics Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl p-6 shadow-lg">
          <div className="text-center">
            <div className="text-3xl font-bold mb-2">
              {totalChallengeDays * totalTasks}
            </div>
            <p className="text-blue-100">Total Tasks</p>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl p-6 shadow-lg">
          <div className="text-center">
            <div className="text-3xl font-bold mb-2">
              {completedTasks.length + completedSubTasks.length}
            </div>
            <p className="text-green-100">Tasks & Subjects</p>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-xl p-6 shadow-lg">
          <div className="text-center">
            <div className="text-3xl font-bold mb-2">
              {Math.round((dailyProgress + subTaskProgress) / 2)}%
            </div>
            <p className="text-orange-100">Overall Progress</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-poppins font-semibold text-gray-800 mb-4">
          🚀 Quick Actions
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button
            onClick={handleResetDay}
            className="bg-primary text-white hover:bg-blue-600"
            disabled={updateProgressMutation.isPending}
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset Day
          </Button>
          <Button
            onClick={handleCompleteAll}
            className="bg-challenge-success text-white hover:bg-green-600"
            disabled={updateProgressMutation.isPending}
          >
            <CheckCheck className="w-4 h-4 mr-2" />
            Complete All
          </Button>
          <Button
            onClick={handleExportData}
            className="bg-challenge-warning text-white hover:bg-yellow-600"
          >
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
          <Button
            variant="secondary"
            className="bg-gray-600 text-white hover:bg-gray-700"
          >
            <Calendar className="w-4 h-4 mr-2" />
            View Calendar
          </Button>
        </div>
      </div>

      {/* Motivational Popup */}
      <MotivationalPopup
        isOpen={showPopup}
        message={popupMessage}
        onClose={() => setShowPopup(false)}
      />
    </div>
  );
}
