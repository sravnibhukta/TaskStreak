import { useEffect } from "react";
import { MotivationalMessage } from "@/lib/motivational-messages";

interface MotivationalPopupProps {
  isOpen: boolean;
  message: MotivationalMessage;
  onClose: () => void;
}

export function MotivationalPopup({ isOpen, message, onClose }: MotivationalPopupProps) {
  useEffect(() => {
    if (isOpen) {
      // Auto close after 3 seconds
      const timer = setTimeout(() => {
        onClose();
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-50"
        onClick={onClose}
      />
      
      {/* Popup */}
      <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 bounce-in">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md mx-auto border-4 border-challenge-success">
          <div className="text-center">
            <div className="text-6xl mb-4">{message.emoji}</div>
            <h3 className="text-2xl font-poppins font-bold text-gray-800 mb-2">
              {message.title}
            </h3>
            <p className="text-gray-600 mb-6">
              {message.message}
            </p>
            <button 
              className="bg-primary text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors font-medium"
              onClick={onClose}
            >
              Continue 💪
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
