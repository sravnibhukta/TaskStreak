import { useState } from "react";
import { Task, SubTask } from "@shared/schema";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle, ChevronDown, ChevronRight } from "lucide-react";

interface AdvancedTaskCardProps {
  task: Task;
  isCompleted: boolean;
  completedSubTasks: string[];
  onToggle: (taskId: string) => void;
  onSubTaskToggle: (subTaskId: string) => void;
}

export function AdvancedTaskCard({ 
  task, 
  isCompleted, 
  completedSubTasks, 
  onToggle, 
  onSubTaskToggle 
}: AdvancedTaskCardProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const hasSubTasks = task.subTasks && task.subTasks.length > 0;
  const completedSubTasksCount = task.subTasks?.filter(st => completedSubTasks.includes(st.id)).length || 0;
  const totalSubTasks = task.subTasks?.length || 0;

  return (
    <div className={`gradient-card rounded-xl shadow-lg p-6 border-l-4 ${task.borderColor} hover:shadow-xl transition-all duration-300 sparkle ${
      isCompleted ? 'task-completed floating-animation' : ''
    }`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4 flex-1">
          <div className="relative">
            <Checkbox
              checked={isCompleted}
              onCheckedChange={() => onToggle(task.id)}
              className="w-6 h-6"
            />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center">
                {task.emoji} {task.name}
                {isCompleted && (
                  <span className="ml-2 text-green-500">
                    <CheckCircle size={20} />
                  </span>
                )}
              </h3>
              {hasSubTasks && (
                <button
                  onClick={() => setIsExpanded(!isExpanded)}
                  className="flex items-center text-gray-500 hover:text-gray-700 transition-colors"
                >
                  {isExpanded ? (
                    <ChevronDown size={20} />
                  ) : (
                    <ChevronRight size={20} />
                  )}
                  <span className="ml-1 text-sm">
                    {completedSubTasksCount}/{totalSubTasks}
                  </span>
                </button>
              )}
            </div>
            <p className="text-gray-600">
              {task.timeSlot} • {task.description}
            </p>
          </div>
        </div>
        <div className="text-right ml-4">
          <div className={`text-sm font-medium ${task.badgeColor} px-3 py-1 rounded-full`}>
            {task.duration} min
          </div>
        </div>
      </div>

      {/* Sub-tasks */}
      {hasSubTasks && isExpanded && (
        <div className="mt-4 pl-10 space-y-2">
          {task.subTasks!.map((subTask) => (
            <div
              key={subTask.id}
              className={`sub-task-item rounded-lg p-3 flex items-center space-x-3 ${
                completedSubTasks.includes(subTask.id) ? 'bg-green-50 border-green-200' : ''
              }`}
            >
              <Checkbox
                checked={completedSubTasks.includes(subTask.id)}
                onCheckedChange={() => onSubTaskToggle(subTask.id)}
                className="w-5 h-5"
              />
              <span className="text-lg">{subTask.emoji}</span>
              <span className={`font-medium ${
                completedSubTasks.includes(subTask.id) ? 'text-green-700 line-through' : 'text-gray-700'
              }`}>
                {subTask.name}
              </span>
              {completedSubTasks.includes(subTask.id) && (
                <CheckCircle size={16} className="text-green-500 ml-auto" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}