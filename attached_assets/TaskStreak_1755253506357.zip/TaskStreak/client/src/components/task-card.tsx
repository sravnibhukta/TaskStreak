import { Task } from "@shared/schema";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle } from "lucide-react";

interface TaskCardProps {
  task: Task;
  isCompleted: boolean;
  onToggle: (taskId: string) => void;
}

export function TaskCard({ task, isCompleted, onToggle }: TaskCardProps) {
  return (
    <div 
      className={`bg-white rounded-xl shadow-lg p-6 border-l-4 ${task.borderColor} hover:shadow-xl transition-all duration-300 ${
        isCompleted ? 'task-completed' : ''
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Checkbox
              checked={isCompleted}
              onCheckedChange={() => onToggle(task.id)}
              className="w-6 h-6"
            />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800 flex items-center">
              {task.emoji} {task.name}
              {isCompleted && (
                <span className="ml-2 text-green-500">
                  <CheckCircle size={20} />
                </span>
              )}
            </h3>
            <p className="text-gray-600">
              {task.timeSlot} • {task.description}
            </p>
          </div>
        </div>
        <div className="text-right">
          <div className={`text-sm font-medium ${task.badgeColor} px-3 py-1 rounded-full`}>
            {task.duration} minutes
          </div>
        </div>
      </div>
    </div>
  );
}
