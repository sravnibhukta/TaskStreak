# Study Task Tracker

## Overview

A full-stack web application for tracking daily study tasks and habits. The application allows users to monitor their progress on various learning activities including GATE exam preparation, yoga sessions, and coding practice. It features a task completion system with motivational feedback, progress visualization, and streak tracking to encourage consistent study habits.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**React Single Page Application**: Built with React 18 using TypeScript for type safety. The frontend utilizes modern React patterns including hooks and functional components. Routing is handled by Wouter, a lightweight client-side router.

**Component Design**: Implements a component-based architecture using shadcn/ui components built on top of Radix UI primitives. This provides accessible, customizable UI components with consistent styling through Tailwind CSS.

**State Management**: Uses TanStack Query (React Query) for server state management, providing efficient data fetching, caching, and synchronization. Local component state is managed through React's built-in useState and useEffect hooks.

**Styling System**: Tailwind CSS with CSS variables for theming support. Custom fonts (Poppins, Inter, Geist Mono) are loaded from Google Fonts. The design system includes a comprehensive color palette and spacing system defined through CSS custom properties.

### Backend Architecture

**Express.js Server**: RESTful API server built with Express.js and TypeScript. The server handles task management and daily progress tracking through well-defined endpoints.

**Storage Layer**: Implements an abstraction layer (IStorage interface) with an in-memory implementation (MemStorage) for development. The system is designed to be easily extended to use database storage in production.

**API Design**: Clean REST endpoints for:
- GET /api/tasks - Retrieve all available tasks
- GET /api/progress/:date - Get daily progress for specific date
- POST /api/progress/:date - Update daily progress with completed tasks

### Data Storage Solutions

**Database Configuration**: Configured for PostgreSQL using Drizzle ORM with Neon Database integration. The schema defines tasks and daily progress tables with proper relationships and constraints.

**Schema Design**: 
- Tasks table: Stores task definitions with metadata like emoji, time slots, descriptions, and visual styling
- Daily Progress table: Tracks completed tasks per date with streak counting and progress metrics

**Development Storage**: Currently uses in-memory storage with pre-populated tasks for development, allowing for quick iteration without database dependencies.

### External Dependencies

**Database**: 
- Neon Database (PostgreSQL) for production data storage
- Drizzle ORM for type-safe database queries and migrations
- Connection pooling through @neondatabase/serverless

**UI Framework**:
- Radix UI primitives for accessible component foundations
- shadcn/ui component library for consistent design system
- Tailwind CSS for utility-first styling

**Development Tools**:
- Vite for fast development builds and hot module replacement
- TypeScript for type safety across the entire stack
- ESBuild for production bundling
- Replit integration for development environment

**Form Handling**:
- React Hook Form for efficient form state management
- Zod for runtime schema validation and type inference

**Date Management**:
- date-fns for date manipulation and formatting utilities

**Fonts & Icons**:
- Google Fonts (Poppins, Inter, Geist Mono) for typography
- Lucide React for consistent iconography

The architecture prioritizes developer experience with hot reloading, type safety, and modern tooling while maintaining a clean separation of concerns between frontend and backend layers.