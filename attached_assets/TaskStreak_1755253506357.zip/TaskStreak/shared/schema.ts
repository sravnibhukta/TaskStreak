import { sql } from "drizzle-orm";
import { pgTable, text, varchar, date, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  emoji: text("emoji").notNull(),
  timeSlot: text("time_slot").notNull(),
  description: text("description").notNull(),
  duration: integer("duration").notNull(), // in minutes
  borderColor: text("border_color").notNull(),
  badgeColor: text("badge_color").notNull(),
  order: integer("order").notNull(),
  subTasks: jsonb("sub_tasks").$type<SubTask[]>().default([]),
  isMainTask: boolean("is_main_task").notNull().default(true),
});

export interface SubTask {
  id: string;
  name: string;
  emoji: string;
  completed?: boolean;
}

export const dailyProgress = pgTable("daily_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: date("date").notNull(),
  completedTasks: jsonb("completed_tasks").$type<string[]>().notNull().default([]),
  completedSubTasks: jsonb("completed_sub_tasks").$type<string[]>().notNull().default([]),
  streakCount: integer("streak_count").notNull().default(0),
  totalTasks: integer("total_tasks").notNull().default(8),
  totalSubTasks: integer("total_sub_tasks").notNull().default(15),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
});

export const insertDailyProgressSchema = createInsertSchema(dailyProgress).omit({
  id: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertDailyProgress = z.infer<typeof insertDailyProgressSchema>;
export type DailyProgress = typeof dailyProgress.$inferSelect;
